<aside class="left_widgets cat_widgets">
	<div class="l_w_title">
		<h3>Account Options</h3>
	</div>
	<div class="widgets_inner">
		<ul class="list">
			<li>
				<a href="<?php echo e(route('orders')); ?>">My Orders</a>
			</li>
			<li>
				<a href="<?php echo e(route('shipping')); ?>">Edit Shipping Address</a>
			</li>
			<li>
				<a href="<?php echo e(route('profile')); ?>#edit-profile">Edit Profile</a>
			</li>
		</ul>
	</div>
</aside><?php /**PATH C:\xampp\htdocs\store\resources\views/partials/profile_sidebar.blade.php ENDPATH**/ ?>