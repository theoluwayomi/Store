<?php $__env->startSection('title', 'Profile'); ?>
<?php $__env->startSection('content'); ?>
<!--================Home Banner Area =================-->
<section class="banner_area">
	<div class="banner_inner d-flex align-items-center">
		<div class="container">
			<div class="banner_content text-center">
				<h2>Profile Page</h2>
				<div class="page_link">
					<a href="<?php echo e(route('landing-page')); ?>">Home</a>
					<a href="<?php echo e(route('profile')); ?>">Profile</a>
				</div>
			</div>
		</div>
	</div>
</section>
<!--================End Home Banner Area =================-->

<!-- ========================= SECTION CONTENT ========================= -->
<section class="section-content padding-y mt-4">
	<?php echo $__env->make('partials.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<div class="container">
		<div class="row">
			<div class="col-md-3">
				<div class="left_sidebar_area">
					<?php echo $__env->make('partials.profile_sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
				</div>
			</div>

			<div class="login_form_inner py-3 col-md-9">
				
				<article class="card mb-3">
					<div class="card-body">
						
						<figure class="icontext">
								<div class="icon">
									<img class="rounded-circle img-sm border" src="<?php echo e(asset('img/instagram/image-01.jpg')); ?>">
								</div>
								<div class="text">
									<strong><?php echo e($user->name()); ?></strong> <br> 
									<?php echo e($user->email); ?><br> 
									<a href="<?php echo e(route('profile')); ?>#edit-profile">Edit</a>
								</div>
						</figure>
						<hr>
						<p>
							<i class="fa fa-map-marker text-muted"></i> &nbsp; My address:  
							 <br>
							<?php echo e($user->shippingaddress->address); ?>&nbsp 
							<a href="<?php echo e(route('shipping')); ?>" class="btn-link">Edit</a>
						</p>
						
						<article class="card-group">
							<figure class="card bg">
								<div class="p-3">
									 <h5 class="card-title"><?php echo e($orderNo); ?></h5>
									<span>Orders</span>
								</div>
							</figure>
							<figure class="card bg">
								<div class="p-3">
									 <h5 class="card-title"><?php echo e($pendingOrders); ?></h5>
									<span>Awaiting delivery</span>
								</div>
							</figure>
							<figure class="card bg">
								<div class="p-3">
									 <h5 class="card-title"><?php echo e($spent); ?>TC</h5>
									<span>Spent so far</span>
								</div>
							</figure>
						</article>
						

					</div> <!-- card-body .// -->
				</article> <!-- card.// -->
				<p class="lead text-dark">View your order details and status below, note that you can also track your order, to track your order contact 09032251515 on WhatsApp immediately.</p>
				<article class="card  mb-3">
					        <div class="my-profile">
            <div class="products-header">
                <h1 class="stylish-heading">My Orders</h1>
            </div>

            <div class="container">
                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="container my-4 mx-2 card row">
                    <div class="order-header row" style="display: flex; background: #F6F6F6; border: 1px solid #DDDDDD;padding: 14px; align-items: center; justify-content:space-between;">
                        <div class="order-header-items" style="display: flex;">
                            <div class="mr-2">
                                <div class="text-uppercase font-weight-bold">Order Placed</div>
                                <div><?php echo e(presentDate($order->created_at)); ?></div>
                            </div>
                            <div class="mr-2">
                                <div class="text-uppercase font-weight-bold">Order ID</div>
                                <div>ORD-<?php echo e($order->id); ?></div>
                            </div>
                            <div class="mr-2">
                                <div class="text-uppercase font-weight-bold">Total</div>
                                <div><?php echo e(presentPrice($order->billing_total)); ?></div>
                            </div>
                        </div>
                        <div class="order-header-items">
                            <div class="text-uppercase font-weight-bold">Status</div>
                            <div class="my-0 alert alert-<?php echo e($order->status == 'pending' ? 'warning' : ''); ?><?php echo e($order->status == 'processed' ? 'primary' : ''); ?><?php echo e($order->status == 'completed' ? 'success' : ''); ?> py-2 text-uppercase"><?php echo e($order->status); ?></div>
                        </div>
                    </div>
                    <div class="order-products row">
                    	<?php

                    	?>
                        <?php $__currentLoopData = $order->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="order-product-item col-md-4" style="display: flex;">
                                <div><img style="max-width: 140px;" src="<?php echo e(asset($product->image)); ?>" alt="Product Image"></div>
                                <div>
                                    <div>
                                        <a href="<?php echo e(route('product', $product->slug)); ?>"><?php echo e($product->name); ?></a>
                                    </div>
                                    <div><?php echo e(presentPrice($product->price)); ?>SC</div>
                                    <div>Quantity: <?php echo e($product->pivot->quantity); ?></div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                </div> <!-- end order-container -->
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php echo e($orders->links()); ?>

            <div class="spacer"></div>
        </div>
				</article> <!-- card.// -->

			</div> <!-- col.// -->
		</div>
	</div> <!-- container .//  -->
</section>
<!-- ========================= SECTION CONTENT END// ========================= -->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('css'); ?>
<style type="text/css">
.my-orders .order-container {
  margin-bottom: 64px;
}

.my-orders .order-header {
  background: #F6F6F6;
  border: 1px solid #DDDDDD;
  padding: 14px;
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.my-orders .order-products {
  background: white;
  border: 1px solid #DDDDDD;
  border-top: none;
  padding: 14px;
}

.my-orders .order-header-items {
  display: flex;
}

.my-orders .order-header-items div {
  margin-right: 14px;
}

.my-orders .order-product-item {
  display: flex;
  margin: 32px 0;
}

.my-orders .order-product-item img {
  max-width: 140px;
  margin-right: 24px;
}

</style>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\store\resources\views/main/user/orders.blade.php ENDPATH**/ ?>