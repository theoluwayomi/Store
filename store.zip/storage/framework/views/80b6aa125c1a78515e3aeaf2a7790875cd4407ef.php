<?php $__env->startSection('title', 'Shopping Cart'); ?>
<?php $__env->startSection('content'); ?>
<!--================Home Banner Area =================-->
<section class="banner_area">
	<div class="banner_inner d-flex align-items-center">
		<div class="container">
			<div class="banner_content text-center">
				<h2>Shopping Cart</h2>
				<div class="page_link">
					<a href="<?php echo e(route('landing-page')); ?>">Home</a>
					<a href="<?php echo e(route('cart')); ?>">Cart</a>
				</div>
			</div>
		</div>
	</div>
</section>
<!--================End Home Banner Area =================-->

<!--================Cart Area =================-->
<section class="cart_area">
	<div class="container">
		<div class="cart_inner">
			
			<div class="table-r	esponsive">
				<table class="table">
					<thead>
						<tr>
							<th scope="col">Product</th>
							<th scope="col">Price</th>
							<th scope="col">Quantity</th>
							<th scope="col">Total</th>
						</tr>
					</thead>
					<tbody>
						<?php if(Cart::count() > 0): ?>

            			<h2><?php echo e(Cart::count()); ?> item(s) in Shopping Cart</h2>
            			<?php
            			$i = 1;
            			?>
            			<?php $__currentLoopData = Cart::content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td>
								<div class="media">
									<div class="d-flex">
										<img src="img/product/single-product/cart-1.jpg" alt="">
									</div>
									<div class="media-body">
										<p><?php echo e($item->model->name); ?></p>
									</div>
								</div>
							</td>
							<td>
								<h5>&#8358;<?php echo e(presentPrice($item->price)); ?></h5>
							</td>
							<td>
								<div>
									<select class="quantity" data-id="<?php echo e($item->rowId); ?>" data-productQuantity="<?php echo e($item->model->quantity); ?>">
	                                <?php for($i = 1; $i < 5 + 1 ; $i++): ?>
	                                    <option <?php echo e($item->qty == $i ? 'selected' : ''); ?>><?php echo e($i); ?></option>
	                                <?php endfor; ?>
                            		</select>
		                            <form action="<?php echo e(route('cart.destroy', $item->rowId)); ?>" method="POST">
		                                <?php echo e(csrf_field()); ?>

		                                <?php echo e(method_field('DELETE')); ?>


		                                <button data-toggle="tooltip" title="Remove" type="submit" class="btn btn-sm"><i class="fa fa-times text-danger"></i></button>
		                            </form>
								</div>
							</td>
							<td>
								<h5>&#8358;<?php echo e(presentPrice($item->total)); ?></h5>
							</td>
						</tr>
						<?php $i++; ?>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<tr class="bottom_button">
							<td>
								
							</td>
							<td>

							</td>
							<td>

							</td>
							<td>
								
							</td>
						</tr>
						<tr>
							<td>

							</td>
							<td>

							</td>
							<td>
								<h5>Tax</h5>
							</td>
							<td>
								<h5>&#8358;<?php echo e(presentPrice($newTax)); ?></h5>
							</td>
						</tr>
						<tr>
							<td>

							</td>
							<td>

							</td>
							<td>
								<h5>Total</h5>
							</td>
							<td>
								<h5>&#8358;<?php echo e(presentPrice($newSubtotal)); ?></h5>
							</td>
						</tr>
						<?php else: ?>
						<tr>
							<td colspan="4"><h3 class="text-center">No items in Cart!</h3></td>
						</tr>
		                
		                <?php endif; ?>
						<tr class="out_button_area">
							<td>

							</td>
							<td>

							</td>
							<td>

							</td>
							<td>
								<div class="checkout_btn_inner">
									<a class="gray_btn" href="<?php echo e(route('category')); ?>">Continue Shopping</a>
									<a class="main_btn" href="<?php echo e(route('checkout')); ?>">Proceed to checkout</a>
								</div>
							</td>
						</tr>
					</tbody>
				</table>
			</div>

		</div>
	</div>
</section>
<!--================End Cart Area =================-->

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
    <script>
        (function(){
            const classname = document.querySelectorAll('.quantity')
            Array.from(classname).forEach(function(element) {
            	element.addEventListener('change', function() {
                    const id = element.getAttribute('data-id')
                    const productQuantity = element.getAttribute('data-productQuantity')

                    axios.patch(`/cart/${id}`, {
                        quantity: this.value,
                        productQuantity: productQuantity
                    })
                    .then(function (response) {
                    	// alert(response.data);
                        // console.log(response.data);
                        window.location.href = '<?php echo e(route('cart')); ?>'
                    })
                    .catch(function (error) {
                        // console.log(error);
                        window.location.href = '<?php echo e(route('cart')); ?>'
                    });
                })
            })
        })();
    </script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\store\resources\views/main/cart.blade.php ENDPATH**/ ?>