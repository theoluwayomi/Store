<?php $__env->startSection('title', 'Profile'); ?>
<?php $__env->startSection('content'); ?>
<!--================Home Banner Area =================-->
<section class="banner_area">
	<div class="banner_inner d-flex align-items-center">
		<div class="container">
			<div class="banner_content text-center">
				<h2>Profile Page</h2>
				<div class="page_link">
					<a href="<?php echo e(route('landing-page')); ?>">Home</a>
					<a href="<?php echo e(route('profile')); ?>">Profile</a>
				</div>
			</div>
		</div>
	</div>
</section>
<!--================End Home Banner Area =================-->

<!-- ========================= SECTION CONTENT ========================= -->
<section class="section-content padding-y mt-4">
	<?php echo $__env->make('partials.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<div class="container">
		<div class="row">
			<div class="col-md-3">
				<div class="left_sidebar_area">
					<?php echo $__env->make('partials.profile_sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
				</div>
			</div>

			<div class="login_form_inner py-3 col-md-9">
				
				<article class="card mb-3">
					<div class="card-body">
						
						<figure class="icontext">
								<div class="icon">
									<img class="rounded-circle img-sm border" src="<?php echo e(asset('img/instagram/image-01.jpg')); ?>">
								</div>
								<div class="text">
									<strong><?php echo e($user->name()); ?></strong> <br> 
									<?php echo e($user->email); ?><br> 
									<a href="<?php echo e(route('profile')); ?>#edit-profile">Edit</a>
								</div>
						</figure>
						<hr>
						<p>
							<i class="fa fa-map-marker text-muted"></i> &nbsp; My address:  
							 <br>
							<?php echo e($user->shippingaddress->address); ?>&nbsp 
							<a href="<?php echo e(route('shipping')); ?>" class="btn-link">Edit</a>
						</p>
					</div> <!-- card-body .// -->
				</article> <!-- card.// -->
				<p class="lead text-dark">Update your shipping details below, please note that your goods will be delivered to the specified address below.</p>
				<article class="card  mb-3">
					<div class="card-body">
						<h5 class="card-title mb-4">Edit Shipping Details </h5>
						<form class="row contact_form" action="<?php echo e(route('shipping.update')); ?>" method="post">
						<?php echo method_field('patch'); ?>
                    	<?php echo csrf_field(); ?>
						<div class="col-md-6 form-group p_star">
							<input type="text" class="form-control" id="first" name="firstname"  placeholder="First Name*" onfocus="this.placeholder = ''" onblur="this.placeholder = 'First Name*'" value="<?php echo e($shipping->firstname); ?>">
						</div>
						<div class="col-md-6 form-group p_star">
							<input type="text" class="form-control" id="last" name="lastname"placeholder="Last Name*" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Last Name*'" value="<?php echo e($shipping->lastname); ?>">
						</div>
						<div class="col-md-12 form-group">
							<input type="text" class="form-control" id="company" name="companyname" placeholder="Company" value="<?php echo e($shipping->companyname); ?>" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Company'">
						</div>
						<div class="col-md-6 form-group p_star">
							<input type="text" class="form-control" id="number" name="mobilenumber" placeholder="Phone number" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Phone number'" value="<?php echo e($shipping->mobilenumber); ?>">
						</div>
						<div class="col-md-6 form-group p_star">
							<input type="text" class="form-control" id="email" name="email" placeholder="Email" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Email'" value="<?php echo e($shipping->email); ?>">
						</div>
						<div class="col-md-12 form-group p_star">
							<input type="text" class="form-control" id="address" name="address" placeholder="Address*" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Address*'" value="<?php echo e($shipping->address); ?>">
						</div>
						<div class="col-md-12 form-group p_star">
							<input type="text" class="form-control" id="city" name="city" placeholder="City*" onfocus="this.placeholder = ''" onblur="this.placeholder = 'City*'" value="<?php echo e($shipping->city); ?>">
						</div>
						<div class="col-md-12 form-group p_star">
							<input type="text" class="form-control" id="state" name="state" placeholder="State*" onfocus="this.placeholder = ''" onblur="this.placeholder = 'State*'" value="<?php echo e($shipping->state); ?>">
						</div>
						<div class="col-md-12 form-group">
							<input type="text" class="form-control" id="zip" name="postalcode" placeholder="Postcode/ZIP" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Postcode/ZIP'" value="<?php echo e($shipping->postalcode); ?>">
						</div>
						<div class="col-md-12 mt-10">
							<button type="submit" value="submit" class="btn submit_btn">Save Changes</button>
						</div>
					</form>
					</div> <!-- card-body .// -->
				</article> <!-- card.// -->

			</div> <!-- col.// -->
		</div>
	</div> <!-- container .//  -->
</section>
<!-- ========================= SECTION CONTENT END// ========================= -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\store\resources\views/main/user/shipping.blade.php ENDPATH**/ ?>