<?php $__env->startSection('title', 'Single Product'); ?>
<?php $__env->startSection('content'); ?>
<!--================Home Banner Area =================-->
<section class="banner_area">
	<div class="banner_inner d-flex align-items-center">
		<div class="container">
			<div class="banner_content text-center">
				<h2>Single Product Page</h2>
				<div class="page_link">
					<a href="<?php echo e(route('landing-page')); ?>">Home</a>
					<a href="<?php echo e(route('category')); ?>">Category</a>
					<a href="<?php echo e(route('product', $product->slug)); ?>"><?php echo e($product->name); ?></a>
				</div>
			</div>
		</div>
	</div>
</section>
<!--================End Home Banner Area =================-->

<!--================Single Product Area =================-->
<div class="product_image_area">
	<div class="container">
		<div class="row s_product_inner">
			<div class="col-lg-6">
				<div class="s_product_img">
					<div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
						<ol class="carousel-indicators">
							<li data-target="#carouselExampleIndicators" data-slide-to="0" class="active">
								<img src="img/product/single-product/s-product-s-2.jpg" alt="">
							</li>
							<li data-target="#carouselExampleIndicators" data-slide-to="1">
								<img src="img/product/single-product/s-product-s-3.jpg" alt="">
							</li>
							<li data-target="#carouselExampleIndicators" data-slide-to="2">
								<img src="img/product/single-product/s-product-s-4.jpg" alt="">
							</li>
						</ol>
						<div class="carousel-inner">
							<div class="carousel-item active">
								<img class="d-block w-100" src="img/product/single-product/s-product-1.jpg" alt="First slide">
							</div>
							<div class="carousel-item">
								<img class="d-block w-100" src="img/product/single-product/s-product-1.jpg" alt="Second slide">
							</div>
							<div class="carousel-item">
								<img class="d-block w-100" src="img/product/single-product/s-product-1.jpg" alt="Third slide">
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="col-lg-5 offset-lg-1">
				<div class="s_product_text">
					<h3><?php echo e($product->name); ?></h3>
					<h2>&#8358; <?php echo e(presentPrice($product->price)); ?></h2>
					<ul class="list">
						<li>
							<a class="active" href="#">
								<span>Category</span> : <?php echo $category; ?></a>
						</li>
						<li>
							<a href="#">
								<span>Availibility</span> : <?php echo $stockLevel; ?></a>
						</li>
					</ul>
					<p><?php echo e($product->details); ?></p>
					<div class="product_count">
						<label for="qty">Quantity:</label>
						<input type="text" name="qty" id="sst" maxlength="12" value="1" title="Quantity:" class="input-text qty">
						<button onclick="var result = document.getElementById('sst'); var sst = result.value; if( !isNaN( sst )) result.value++;return false;"
						 class="increase items-count" type="button">
							<i class="lnr lnr-chevron-up"></i>
						</button>
						<button onclick="var result = document.getElementById('sst'); var sst = result.value; if( !isNaN( sst ) &amp;&amp; sst > 0 ) result.value--;return false;"
						 class="reduced items-count" type="button">
							<i class="lnr lnr-chevron-down"></i>
						</button>
					</div>
					<div class="card_area">
						<form method="post" action="<?php echo e(route('cart.store', $product)); ?>">
							<?php echo csrf_field(); ?>
							<button class="<?php echo e((!$product->inStock()) ? 'btn btn-danger' : 'main_btn'); ?>" type="submit" <?php echo e((!$product->inStock()) ? 'disabled' : ''); ?>><?php echo e((!$product->inStock()) ? 'Sold Out!' : 'Add to Cart'); ?></button>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<!--================End Single Product Area =================-->

<!--================Product Description Area =================-->
<section class="product_description_area">
	<div class="container">
		<ul class="nav nav-tabs" id="myTab" role="tablist">
			<li class="nav-item">
				<a class="nav-link" id="home-tab" data-toggle="tab" href="#home" role="tab" aria-controls="home" aria-selected="true">Description</a>
			</li>
		</ul>
		<div class="tab-content" id="myTabContent">
			<div class="tab-pane active" id="home" role="tabpanel" aria-labelledby="home-tab">
				<p><?php echo e($product->description); ?></p>
			</div>
		</div>
	</div>
</section>
<!--================End Product Description Area =================-->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\store\resources\views/main/single-product.blade.php ENDPATH**/ ?>