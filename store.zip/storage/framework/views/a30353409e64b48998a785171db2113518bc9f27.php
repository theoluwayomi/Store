<?php $__env->startSection('title', 'Confirmation'); ?>
<?php $__env->startSection('content'); ?>
<!--================Home Banner Area =================-->
<section class="banner_area">
	<div class="banner_inner d-flex align-items-center">
		<div class="container">
			<div class="banner_content text-center">
				<h2>Order Confirmation</h2>
				<div class="page_link">
					<a href="<?php echo e(route('landing-page')); ?>">Home</a>
					<a href="<?php echo e(route('confirmation')); ?>">Confirmation</a>
				</div>
			</div>
		</div>
	</div>
</section>
<!--================End Home Banner Area =================-->

<!--================Order Details Area =================-->
<section class="order_details p_120">
	<?php echo $__env->make('partials.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<div class="container">
		<h3 class="title_confirmation">Thank you. Your order has been received.</h3>
		<div class="row order_d_inner ">
			<div class="col-lg-4">
				<div class="details_item">
					<h4>Order Info</h4>
					<ul class="list">
						<li>
							<a href="#">
								<span>Order number</span> : ORD-<?php echo e($order->id); ?></a>
						</li>
						<li>
							<a href="#">
								<span>Date</span> : <?php echo e(presentDate($order->created_at)); ?></a>
						</li>
						<li>
							<a href="#">
								<span>Total</span> : <?php echo e(presentPrice($order->billing_total)); ?>TC</a>
						</li>
						<li>
							<a href="#">
								<span>Payment method</span> : Store Credit</a>
						</li>
					</ul>
				</div>
			</div>
			<div class="col-lg-4">
				<div class="details_item">
					<h4>Shipping Address</h4>
					<ul class="list">
						<li>
							<a href="#">
								<span>Address</span> : <?php echo e(auth()->user()->shippingaddress->address); ?></a>
						</li>
						<li>
							<a href="#">
								<span>City</span> : <?php echo e(auth()->user()->shippingaddress->city); ?></a>
						</li>
						<li>
							<a href="#">
								<span>State</span> : <?php echo e(auth()->user()->shippingaddress->state); ?></a>
						</li>
						<li>
							<a href="#">
								<span>Postcode </span> : <?php echo e(isset(auth()->user()->shippingaddress->postalcode) ? auth()->user()->shippingaddress->postalcode : 'Nil'); ?></a>
						</li>
					</ul>
				</div>
			</div>
		</div>
	</div>
</section>
<!--================End Order Details Area =================-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\store\resources\views/main/confirmation.blade.php ENDPATH**/ ?>