<?php $__env->startSection('title', 'Profile'); ?>
<?php $__env->startSection('content'); ?>
<!--================Home Banner Area =================-->
<section class="banner_area">
	<div class="banner_inner d-flex align-items-center">
		<div class="container">
			<div class="banner_content text-center">
				<h2>Profile Page</h2>
				<div class="page_link">
					<a href="index.html">Home</a>
					<a href="index.html">Profile</a>
				</div>
			</div>
		</div>
	</div>
</section>
<!--================End Home Banner Area =================-->

<!-- ========================= SECTION CONTENT ========================= -->
<section class="section-content padding-y mt-4">
	<div class="container">
		<div class="row">
			<div class="col-md-3">
				<div class="left_sidebar_area">
					<?php echo $__env->make('partials.profile_sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
				</div>
			</div>

			<div class="login_form_inner py-3 col-md-9">

				<article class="card mb-3">
					<div class="card-body">
						
						<figure class="icontext">
								<div class="icon">
									<img class="rounded-circle img-sm border" src="<?php echo e(asset('img/instagram/image-01.jpg')); ?>">
								</div>
								<div class="text">
									<strong> Mr. Jackson Someone </strong> <br> 
									myloginname@gmail.com <br> 
									<a href="<?php echo e(route('edit-profile')); ?>">Edit</a>
								</div>
						</figure>
						<hr>
						<p>
							<i class="fa fa-map-marker text-muted"></i> &nbsp; My address:  
							 <br>
							Tashkent city, Street name, Building 123, House 321 &nbsp 
							<a href="<?php echo e(route('shipping')); ?>" class="btn-link">Edit</a>
						</p>
					</div> <!-- card-body .// -->
				</article> <!-- card.// -->

				<article class="card  mb-3">
					<div class="card-body">
						<h5 class="card-title mb-4">Edit Details </h5>	

						<form action="#">
							<div class="row">
								<div class="col-md-6 mt-10">
									<input type="text" name="lastname" placeholder="Last Name" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Last Name'"
									 required class="single-input">
								</div>
								<div class="col-md-6 mt-10">
									<input type="text" name="firstname" placeholder="First Name" onfocus="this.placeholder = ''" onblur="this.placeholder = 'First Name'"
									 required class="single-input">
								</div>
							</div>
							<div class="row">
								<div class="col-md-6 mt-10">
									<input type="text" name="username" placeholder="User Name" onfocus="this.placeholder = ''" onblur="this.placeholder = 'User Name'"
									 required class="single-input">
								</div>
								<div class="col-md-6 mt-10">
									<input type="email" name="email" placeholder="Email address" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Email address'"
									 required class="single-input">
								</div>
							</div>
							<div class="row">
								<div class="col-md-6 mt-10">
									<input type="text" name="mobilenumber" placeholder="Mobile number" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Mobile number'"
									 autocomplete="none" class="single-input">
								</div>
							</div>
							<hr>
							<div class="row">
								<div class="col-md-6 mt-10">
									<input type="password" name="password" placeholder="Password" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Password'"
									 required class="single-input">
								</div>
								<div class="col-md-6 mt-10">
									<input type="password" name="password" placeholder="New Password" onfocus="this.placeholder = ''" onblur="this.placeholder = 'New Password'"
									 required class="single-input">
								</div>
							</div>
							<div class="row justify-content-center">
								<div class="col-md-6 mt-10">
									<input type="password" name="password" placeholder="Confirm New Password" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Confirm New Password'"
									 required class="single-input">
								</div>
							</div>
							<div class="mt-10">
								<button type="submit" value="submit" class="btn submit_btn">Save Changes</button>
							</div>
						</form>
					</div> <!-- card-body .// -->
				</article> <!-- card.// -->

			</div> <!-- col.// -->
		</div>
	</div> <!-- container .//  -->
</section>
<!-- ========================= SECTION CONTENT END// ========================= -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\store\resources\views/main/user/settings.blade.php ENDPATH**/ ?>