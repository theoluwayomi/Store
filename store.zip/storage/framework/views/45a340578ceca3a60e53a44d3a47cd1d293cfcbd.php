<?php $__env->startSection('title', 'Categories'); ?>
<?php $__env->startSection('content'); ?>
<!--================Home Banner Area =================-->
<section class="banner_area">
	<div class="banner_inner d-flex align-items-center">
		<div class="container">
			<div class="banner_content text-center">
				<h2>Shop Category Page</h2>
				<div class="page_link">
					<a href="<?php echo e(route('landing-page')); ?>">Home</a>
					<a href="<?php echo e(route('category')); ?>">Category</a>
					<a href="<?php echo e(route('category', ['category' => request()->category])); ?>"><?php echo e($categoryName); ?></a>
				</div>
			</div>
		</div>
	</div>
</section>
<!--================End Home Banner Area =================-->

<!--================Category Product Area =================-->
<section class="cat_product_area section_gap">
	<div class="container-fluid">
		<div class="row flex-row-reverse">
			<div class="col-lg-9">
				<div class="product_top_bar">
					<h3><?php echo e($categoryName); ?></h3>
					<hr> 
					<div class="left_dorp">
						<select class="sorting" id="sorting">
							<option value="">Default</option>
							<option value="low_high" <?php echo e(isset(request()->sort) && (request()->sort == 'low_high') ? 'selected' : ''); ?>>Price: Low to High</option>
							<option value="high_low" <?php echo e(isset(request()->sort) && (request()->sort == 'high_low') ? 'selected' : ''); ?>>Price: High to Low</option>
						</select>
					</div>
					<div class="right_page ml-auto">
						<?php echo e($products->links()); ?>

					</div>
				</div>
				<div class="latest_product_inner row">
                	<?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
					<div class="col-lg-3 col-md-3 col-sm-6">
						<div class="f_p_item">
							<div class="f_p_img">
								<img class="img-fluid" src="<?php echo e($product->image); ?>" alt="">
								<div class="p_icon">
									<form method="post" action="<?php echo e(route('cart.store', $product)); ?>">
	                                    <?php echo csrf_field(); ?>
	                                    <button type="submit" class="btn">
	                                        <i class="lnr lnr-cart"></i>
	                                    </buttom>
	                                </form>
								</div>
							</div>
							<a href="<?php echo e(route('product', $product->slug)); ?>">
								<h4><?php echo e($product->name); ?></h4>
							</a>
							<h5>&#8358;<?php echo e(presentPrice($product->price)); ?></h5>
						</div>
					</div>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
					<h3 class="text-center ml-5">No Product found for this category!</h3>
					<?php endif; ?>
				</div>
			</div>
			<div class="col-lg-3">
				<div class="left_sidebar_area">
					<aside class="left_widgets cat_widgets">
						<div class="l_w_title">
							<h3>Browse Categories</h3>
						</div>
						<div class="widgets_inner">
							<ul class="list">
								<li class=""><a href="<?php echo e(route('category')); ?>">Featured Products</a></li>
								<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				                    <li class="<?php echo e(setActiveCategory($category->slug)); ?>"><a href="<?php echo e(route('category', ['category' => $category->slug])); ?>"><?php echo e($category->name); ?></a></li>
				                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</ul>
						</div>
					</aside>
					
				</div>
			</div>
		</div>
		
		<div class="row mt-2">
			<?php echo e($products->links()); ?>

		</div>
	</div>
</section>
<!--================End Category Product Area =================-->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script type="text/javascript">
	$(document).ready(function() {
        $("#sorting").change(function() {
            var option = $("#sorting option:selected").val();
            if (option.length) {

            	var arg = "<?php echo (isset(request()->category) or isset(request()->sort) or isset(request()->pg)) ?>";
            	

            	var address = "<?php echo url()->full(); ?>";
            	var clean_uri = address.substring(0, address.indexOf("?"));

            	if(arg) {
            		var category = "<?php echo request()->category; ?>";
            		if(category.length > 0) {
            			clean_uri += "?category="+category+"&";
            		} else {
            			clean_uri += "?";
            		}
            		clean_uri += "sort="+option+"&";
            		var pg = "<?php echo request()->pg; ?>";
            		if(pg.length > 0) {
            			clean_uri += "pg="+pg;
            		}
            	} else {
            		clean_uri += "?sort=" + option;
            	}

            	location = clean_uri;
            }
        });
    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\store\resources\views/main/category.blade.php ENDPATH**/ ?>