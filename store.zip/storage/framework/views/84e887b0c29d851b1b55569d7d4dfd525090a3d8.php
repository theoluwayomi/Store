<!--================Header Menu Area =================-->
	<header class="header_area">
		<div class="top_menu row m0">
			<div class="container-fluid">
				<div class="float-left">
					<p>Call Us: <a href="tel:+2349032251515">09032251515</a> </p>
				</div>
				<div class="float-right">
					<ul class="right_side">
						<?php if(auth()->guard()->guest()): ?>
						<li>
							<a href="<?php echo e(route('login')); ?>">
								Login/Register
							</a>
						</li>
						<?php else: ?>
						<li>
							<a href="<?php echo e(route('profile')); ?>">
								My Account
							</a>
						</li>
						<?php endif; ?>
					</ul>
				</div>
			</div>
		</div>
		<div class="main_menu">
			<nav class="navbar navbar-expand-lg navbar-light">
				<div class="container-fluid">
					<!-- Brand and toggle get grouped for better mobile display -->
					<a class="navbar-brand logo_h" href="<?php echo e(route('landing-page')); ?>">
						<img src="img/logo.jpg" alt="">
					</a>
					<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
					 aria-expanded="false" aria-label="Toggle navigation">
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
					<!-- Collect the nav links, forms, and other content for toggling -->
					<div class="collapse navbar-collapse offset" id="navbarSupportedContent">
						<div class="row w-100">
							<div class="col-lg-7 pr-0">
								<ul class="nav navbar-nav center_nav pull-right">
									<li class="nav-item active">
										<a class="nav-link" href="<?php echo e(route('landing-page')); ?>">Home</a>
									</li>
									<li class="nav-item submenu dropdown">
										<a href="<?php echo e(route('category')); ?>" class="nav-link dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Category</a>
										<ul class="dropdown-menu">
											<?php $__currentLoopData = listCategories(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<li class="nav-item">
												<a class="nav-link" href="<?php echo e(route('category', ['category' => $category->slug])); ?>"><?php echo e($category->name); ?></a>
											</li>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</ul>
									</li>
									<?php if(auth()->guard()->guest()): ?>
									<li class="nav-item">
										<a class="nav-link" href="<?php echo e(route('login')); ?>">Login</a>
									</li>
									<li class="nav-item">
										<a class="nav-link" href="<?php echo e(route('register')); ?>">Register</a>
									</li>
									<?php else: ?>
									<li class="nav-item submenu dropdown">
										<a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Store Credit</a>
										<ul class="dropdown-menu">
											<li class="nav-item">
												<a class="nav-link" href="<?php echo e(route('buy')); ?>">Buy Store Credit</a>
											</li>
											<li class="nav-item">
												<a class="nav-link" href="<?php echo e(route('sell')); ?>">Sell Store Credit</a>
											</li>
											<li class="nav-item">
												<a class="nav-link" href="<?php echo e(route('transfer')); ?>">Transfer Store Credit</a>
											</li>
										</ul>
									</li>
									<li class="nav-item">
										<a class="nav-link" href="<?php echo e(route('verify')); ?>">Verify User</a>
									</li>
									<?php endif; ?>
								</ul>
							</div>

							<div class="col-lg-5">
								<ul class="nav navbar-nav navbar-right right_nav pull-right">
									<hr>
									<?php if(auth()->guard()->guest()): ?>
									<?php else: ?>
									<li class="nav-item">
										<a href="javascript:{}" class="icons">
											<span style="font-size: 70%;"><?php echo e(presentPrice(Auth::user()->wallet->balance)); ?>TC</span>
										</a>
									</li>
									<hr>
									<li class="nav-item submenu dropdown">
										<a href="" class="nav-link dropdown-toggle icons" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><i class="fa fa-user" aria-hidden="true"></i></a>
										<ul class="dropdown-menu">
											<li class="nav-item">
												<a class="nav-link" href="<?php echo e(route('profile')); ?>">Dashboard</a>
											</li>
											<li class="nav-item">
												<a class="nav-link" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();document.getElementById('logout-form').submit();">Logout</a>
											</li>
										</ul>
									</li>
									<form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
									    <?php echo e(csrf_field()); ?>

									</form>
									<?php endif; ?>
									<hr>

									<li class="nav-item">
										<a href="<?php echo e(route('cart')); ?>" class="icons">
											<i class="lnr lnr lnr-cart" style="position: relative;">
												<?php if(Cart::instance('default')->count() > 0): ?>
												<span class="badge badge-info" style="position: absolute; top: -12px; right: -10px;"><?php echo e(Cart::instance('default')->count()); ?></span>
												<?php endif; ?>
											</i>
										</a>
									</li>

									<hr>
								</ul>
							</div>
						</div>
					</div>
				</div>
			</nav>
		</div>
	</header>
	<!--================Header Menu Area =================--><?php /**PATH C:\xampp\htdocs\store\resources\views/partials/nav.blade.php ENDPATH**/ ?>