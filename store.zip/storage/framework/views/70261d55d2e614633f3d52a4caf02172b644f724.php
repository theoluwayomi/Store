<?php $__env->startSection('content'); ?>
<!--================Home Banner Area =================-->
<section class="banner_area">
    <div class="banner_inner d-flex align-items-center">
        <div class="container">
            <div class="banner_content text-center">
                <h2>Verify User</h2>
                <div class="page_link">
                    <a href="<?php echo e(route('home')); ?>">Home</a>
                    <a href="<?php echo e(route('verify')); ?>">Verify User</a>
                </div>
            </div>
        </div>
    </div>
</section>
<!--================End Home Banner Area =================-->

<!-- ========================= SECTION CONTENT ========================= -->
<section class="tracking_box_area mt-3">
    <?php echo $__env->make('partials.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container">
        <div class="tracking_box_inner">
            <h4 class="text-left py-3"><strong>Verify Users</strong></h4>
            <p>Input the WhatsApp number without the international codes(e.g. +234) to verify buyer or seller authenticity.</p>
            <p><strong>It is very important to verify a buyer's or a seller's account before buying or selling store credit from/to them.</strong></p>
            <form class="row tracking_form" action="<?php echo e(route('verify.search')); ?>" method="post" novalidate="novalidate">
                <?php echo csrf_field(); ?>
                <div class="col-md-12 form-group">
                    <input type="text" class="form-control" id="mobilenumber" name="mobilenumber" placeholder="Mobile number">
                </div>
                <div class="col-md-12 form-group">
                    <button type="submit" value="submit" class="btn submit_btn">Verify User</button>
                </div>
            </form>

            <div class="jumbotron text-center mt-4">
                <?php if(session()->has('user')): ?>
                <?php
                $user = session()->get('user');
                ?>
                    <?php if(!is_bool($user)): ?>
                    <p><strong>Name</strong>: <?php echo e($user->lastname); ?> <?php echo e($user->firstname); ?> <i class="fa fa-check text-success"></i></p>
                    <p><strong>Email</strong>: <?php echo e($user->email); ?></p>
                    <p><strong>Mobile number</strong>: <?php echo e($user->mobilenumber); ?></p>
                    <p><strong>Balance</strong>: <?php echo e($user->wallet->balance()); ?>SC</p>
                    <?php else: ?>
                    <h5 class="text-danger text-center"><strong>User could not be found. Check to make sure you did not add country code to the number</strong>!</h5>
                    <?php endif; ?>
                <?php else: ?>
                    <h5 class="text-danger text-center"><strong>Verify seller's or buyer's account before transacting with the person.<br>
                    <br>Make sure the seller or buyer is chatting with you with the WhatsApp number you want to verify.</strong></h5>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\store\resources\views/main/storecredit/verify_user.blade.php ENDPATH**/ ?>