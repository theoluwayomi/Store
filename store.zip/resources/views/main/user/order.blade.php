@extends('layouts.app')

@section('title', 'Profile')
@section('content')
<!--================Home Banner Area =================-->
<section class="banner_area">
	<div class="banner_inner d-flex align-items-center">
		<div class="container">
			<div class="banner_content text-center">
				<h2>Profile Page</h2>
				<div class="page_link">
					<a href="{{ route('landing-page') }}">Home</a>
					<a href="{{ route('profile') }}">Profile</a>
				</div>
			</div>
		</div>
	</div>
</section>
<!--================End Home Banner Area =================-->

<!-- ========================= SECTION CONTENT ========================= -->
<section class="section-content padding-y mt-4">
	@include('partials.message')
	<div class="container">
		<div class="row">
			<div class="col-md-3">
				<div class="left_sidebar_area">
					@include('partials.profile_sidebar')
				</div>
			</div>

			<div class="login_form_inner py-3 col-md-9">

				<article class="card mb-3">
					<div class="card-body">
						
						<figure class="icontext">
								<div class="icon">
									<img class="rounded-circle img-sm border" src="{{ asset('img/instagram/image-01.jpg') }}">
								</div>
								<div class="text">
									<strong>{{ $user->name() }}</strong> <br> 
									{{ $user->email }}<br> 
									<a href="{{ route('profile') }}#edit-profile">Edit</a>
								</div>
						</figure>
						<hr>
						<p>
							<i class="fa fa-map-marker text-muted"></i> &nbsp; My address:  
							 <br>
							{{ $user->shippingaddress->address }}&nbsp 
							<a href="{{ route('shipping') }}" class="btn-link">Edit</a>
						</p>
						
						<article class="card-group">
							<figure class="card bg">
								<div class="p-3">
									 <h5 class="card-title">{{ $orderNo }}</h5>
									<span>Orders</span>
								</div>
							</figure>
							<figure class="card bg">
								<div class="p-3">
									 <h5 class="card-title">{{ $pendingOrders }}</h5>
									<span>Awaiting delivery</span>
								</div>
							</figure>
							<figure class="card bg">
								<div class="p-3">
									 <h5 class="card-title">{{ $spent }}TC</h5>
									<span>Spent so far</span>
								</div>
							</figure>
						</article>
						

					</div> <!-- card-body .// -->
				</article> <!-- card.// -->

				<article class="card  mb-3">
					<div class="my-profile">
			            <div class="products-header">
			                <h1 class="stylish-heading">Order ID: {{ $order->id }}</h1>
			            </div>

			            <div>
			                <div class="order-container">
			                    <div class="order-header">
			                        <div class="order-header-items">
			                            <div>
			                                <div class="uppercase font-bold">Order Placed</div>
			                                <div>{{ presentDate($order->created_at) }}</div>
			                            </div>
			                            <div>
			                                <div class="uppercase font-bold">Order ID</div>
			                                <div>{{ $order->id }}</div>
			                            </div><div>
			                                <div class="uppercase font-bold">Total</div>
			                                <div>{{ presentPrice($order->billing_total) }}</div>
			                            </div>
			                        </div>
			                        <div>
			                            <div class="order-header-items">
			                                <div><a href="#">Invoice</a></div>
			                            </div>
			                        </div>
			                    </div>
			                    <div class="order-products">
			                        <table class="table" style="width:50%">
			                            <tbody>
			                                <tr>
			                                    <td>Name</td>
			                                    <td>{{ $order->user->name }}</td>
			                                </tr>
			                                <tr>
			                                    <td>Address</td>
			                                    <td>{{ $order->billing_address }}</td>
			                                </tr>
			                                <tr>
			                                    <td>City</td>
			                                    <td>{{ $order->billing_city }}</td>
			                                </tr>
			                                <tr>
			                                    <td>Subtotal</td>
			                                    <td>{{ presentPrice($order->billing_subtotal) }}</td>
			                                </tr>
			                                <tr>
			                                    <td>Tax</td>
			                                    <td>{{ presentPrice($order->billing_tax) }}</td>
			                                </tr>
			                                <tr>
			                                    <td>Total</td>
			                                    <td>{{ presentPrice($order->billing_total) }}</td>
			                                </tr>
			                            </tbody>
			                        </table>

			                    </div>
			                </div> <!-- end order-container -->

			                <div class="order-container">
			                    <div class="order-header">
			                        <div class="order-header-items">
			                            <div>
			                                Order Items
			                            </div>

			                        </div>
			                    </div>
			                    <div class="order-products">
			                        @foreach ($products as $product)
			                            <div class="order-product-item">
			                                <div><img src="{{ asset($product->image) }}" alt="Product Image"></div>
			                                <div>
			                                    <div>
			                                        <a href="{{ route('shop.show', $product->slug) }}">{{ $product->name }}</a>
			                                    </div>
			                                    <div>{{ presentPrice($product->price) }}</div>
			                                    <div>Quantity: {{ $product->pivot->quantity }}</div>
			                                </div>
			                            </div>
			                        @endforeach

			                    </div>
			                </div> <!-- end order-container -->
			            </div>

			            <div class="spacer"></div>
			        </div>
				</article> <!-- card.// -->

			</div> <!-- col.// -->
		</div>
	</div> <!-- container .//  -->
</section>
<!-- ========================= SECTION CONTENT END// ========================= -->
@endsection